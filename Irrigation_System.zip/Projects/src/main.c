/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes

volatile struct timermSS {
    uint8_t interval : 1;
    uint32_t count;
    uint32_t timeOut;
} timermS;

typedef enum {
    STATE_IDLE,
    STATE_INIT,
    STATE_RUNNING,
    STATE_ERROR,
    STATE_STANDBY
} State_t;
//static State_t currentState = STATE_IDLE;
// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************
uint32_t TC3period, TC3Counter, TC3Status;


// *****************************************************************************
// *****************************************************************************
// Section:Definitions
// *****************************************************************************
// *****************************************************************************
#define RX_BUFFER_SIZE 20
#define MAX_STATES          5          // Number of states in the state machine
#define DEBOUNCE_TIME_MS    50         // Debounce time in milliseconds

#define NUMADCMEASUREMENTSTOAVERAGE 16
#define NUMLIGHTSENSORMEASUREMENTSTOBUFFER 20 
#define MOISTURELEVELTHRESHOLD 2300
// *****************************************************************************
// *****************************************************************************
// Section: Global variable Set-Up
// *****************************************************************************
// *****************************************************************************

char messageStart [] ="**** USART startup message *****\r\n";
char State_Change []=         "State changed from ";
char STATE_IDLE_message[] =   " System in IDLE State";
char STATE_INIT_message[]=    " System in INIT State";
char STATE_RUNNING_message[]= " System in RUNNING State";
char STATE_ERROR_message[]=   " System in ERROR State";
char STATE_STANDBY_message[]= " System in STANDBY State";
char newline [] = "\r\n";
char receiveBuffer [RX_BUFFER_SIZE] = {};
char transmitBuffer [RX_BUFFER_SIZE] = {};
char errorMessage[] = "\r\n***USART error has occured***\r\n";
char StateMessage[] = "\r\n Moved to stage:";
char data = 0;
volatile State_t currentState = STATE_IDLE;
volatile State_t prevState;
volatile bool buttonPressed = false;
volatile uint32_t lastButtonPressTime = 0;
volatile uint32_t systemTicks = 0;
uint16_t rxCounter =0;

uint8_t  measurementCount = 0;
uint16_t adcResults[NUMADCMEASUREMENTSTOAVERAGE];
uint16_t MoistureSensorData[NUMLIGHTSENSORMEASUREMENTSTOBUFFER];
uint8_t  MoistureSensorDataIndex = 0;  

volatile bool adcConversionComplete = false;
/**********************************
 * Local function prototypes      *
 **********************************/
//void handle_command(char command);
void Check_Commands (void);
void Clear_buffer(void);
void execute_state_actions(void);
void handle_button_press(void);
void Interval1mS(TC_TIMER_STATUS status, uintptr_t context);


void readADC (void);

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************
int main ( void )
{
    /* Initialize all modules */
    timermS.timeOut = 200;     //Set-Up your delay on a ms basis, using TC4.
    SYS_Initialize ( NULL );    
    TC4_TimerCallbackRegister(Interval1mS, (uintptr_t) NULL);
    TC4_TimerStart();        
    SERCOM5_USART_Enable();    
    /*Register interrupt callback*/
    
    ADC_Enable();
    while ( true )
    {
        SYS_Tasks ( );
         SERCOM5_USART_Write (&messageStart[0],sizeof (messageStart));
        //Check_Commands(); 
        if (timermS.interval == 1) 
        {
            timermS.interval = 0;    
//            Check_Commands();
               // Perform state-specific actions            
            if(SW0_Get() == 0)
            {
               //SERCOM5_USART_Write(StateMessage, sizeof StateMessage);
                LED0_Toggle();
//                SERCOM5_USART_Write(StateMessage)                        
                handle_button_press();
            }
            if ( currentState != prevState)
            {
                execute_state_actions();
            }
                   
    }
     return ( EXIT_FAILURE );
    }
}

/*******************************************************************************
 End of File
*/
void Interval1mS(TC_TIMER_STATUS status, uintptr_t context) {
//    GPIO_STATUS_Set();
    if (++timermS.count >= timermS.timeOut) {
        timermS.interval = 1;
        timermS.count = 0;
    }
    systemTicks++;
//    GPIO_STATUS_Clear();
}
void Check_Commands (void){
     if ( SERCOM5_USART_ReceiverIsReady() == true )
        {
            if (SERCOM5_USART_ErrorGet() == USART_ERROR_NONE)
            {
                SERCOM5_USART_Read(&data, 1);
                if ((data == '\n') || (data == '\r'))
                {
                    SERCOM5_USART_Write(&newline[0], sizeof(newline));                   
                    SERCOM5_USART_Write(&receiveBuffer[0], sizeof(receiveBuffer));
                    SERCOM5_USART_Write(&newline[0], sizeof(newline));             
                    rxCounter =0;
                    Clear_buffer();
                }                
                else 
                receiveBuffer[rxCounter++] = data;
               }  
            else 
                SERCOM5_USART_Write(&errorMessage[0], sizeof(errorMessage));               
        }
     }

void Clear_buffer(void){
    for (int i = 0; i < RX_BUFFER_SIZE; i++) 
    {
        receiveBuffer[i] = 0;
    }
}
// Handle button press with debouncing
void handle_button_press(void) {
    uint32_t currentTime = systemTicks;    
    // Check if debounce time has elapsed
    if (currentTime - lastButtonPressTime >= DEBOUNCE_TIME_MS)
    {
        // Transition to next state
        transition_to_next_state();   
        lastButtonPressTime = currentTime;
    }
}
// Transition to next state
void transition_to_next_state(void) {
    prevState = currentState;    
    // Increment state
    currentState = (currentState + 1) % MAX_STATES;

}
void execute_state_actions(void){
//    State_t prevState = currentState;
//    if ( currentState != prevState){
     switch(currentState) {
                case STATE_IDLE:
                    // Idle state actions
                    SERCOM5_USART_Write(&STATE_IDLE_message[0], sizeof(STATE_IDLE_message));
                    SERCOM5_USART_Write(&newline[0], sizeof(newline));
                    break;

                case STATE_INIT:
                    // Init state actions
                    SERCOM5_USART_Write(&STATE_INIT_message[0], sizeof(STATE_INIT_message));
                    SERCOM5_USART_Write(&newline[0], sizeof(newline));
                    break;

                case STATE_RUNNING:
                    // Running state actions
                    SERCOM5_USART_Write(&STATE_RUNNING_message[0], sizeof(STATE_RUNNING_message));
                    SERCOM5_USART_Write(&newline[0], sizeof(newline));
//                    readADC();
                    break;

                case STATE_ERROR:
                    // Error state actions
                    SERCOM5_USART_Write(&STATE_ERROR_message[0], sizeof(STATE_ERROR_message));
                    SERCOM5_USART_Write(&newline[0], sizeof(newline));
                    break;

                case STATE_STANDBY:
                    // Standby state actions
                    SERCOM5_USART_Write(&STATE_STANDBY_message[0], sizeof(STATE_STANDBY_message));
                    SERCOM5_USART_Write(&newline[0], sizeof(newline));
                    break;
            }
    //}
}

/*ADC Stuff*/
// ADC conversion complete callback
void ADC_ResultHandler(uintptr_t result) {
    // Store ADC result in the array
    adcResults[measurementCount++] = result;
    
    // Check if we've collected enough samples
    if (measurementCount >= NUMADCMEASUREMENTSTOAVERAGE) {
        adcConversionComplete = true;
        measurementCount = 0;
    } else {
        // Start another conversion if we need more samples
        ADC_ConversionStart();
    }
}

// Function to read ADC values
void readADC(void) {
    uint32_t sum = 0;
    char adcMessage[50];
    
    // Reset conversion flag
    adcConversionComplete = false;
    measurementCount = 0;
    
    // Register the callback
    ADC_CallbackRegister(ADC_ResultHandler, (uintptr_t)NULL);
    
    // Start the first conversion - the callback will handle subsequent conversions
    ADC_ConversionStart();
    
    // Wait for all conversions to complete
    while (!adcConversionComplete) {
        // Wait for the callback to set the flag
    }
    
    // Calculate average
    for (int i = 0; i < NUMADCMEASUREMENTSTOAVERAGE; i++) {
        sum += adcResults[i];
    }
    uint16_t average = sum / NUMADCMEASUREMENTSTOAVERAGE;
    
    // Store in circular buffer
    MoistureSensorData[MoistureSensorDataIndex] = average;
    MoistureSensorDataIndex = (MoistureSensorDataIndex + 1) % NUMLIGHTSENSORMEASUREMENTSTOBUFFER;
    
    // Check if moisture level is below threshold
    bool isDry = (average > MOISTURELEVELTHRESHOLD); // Assuming higher value = drier soil
    
    // Format message
    sprintf(adcMessage, "Moisture: %d %s\r\n", average, isDry ? "DRY" : "WET");
    
    // Send through UART
    SERCOM5_USART_Write(adcMessage, strlen(adcMessage));
}